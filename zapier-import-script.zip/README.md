# Ouroboros Deployment System

Autonomous full-stack deployment automation for Solana programs with integrated Zapier webhooks, real-time monitoring, and atomic event processing.

## Features

- **Automatic Webhook Wiring**: Events from Solana programs flow directly to Zapier
- **Atomic Idempotency**: Duplicate prevention at every layer with distributed locks
- **Real-time Monitoring**: Live dashboard with system metrics and event tracking
- **Environment Management**: Easy switching between devnet, testnet, and mainnet
- **Error Handling & Retry Logic**: Exponential backoff with configurable retry limits
- **Google Sheets Integration**: Automatic event logging to your spreadsheet
- **Comprehensive Logging**: Detailed logs for debugging and monitoring

## Architecture

\`\`\`
┌─────────────────────────────────────────────────────────────────┐
│                         Your dApp                               │
│                    (Client + Program)                           │
└────────────────────────┬────────────────────────────────────────┘
                         │
                    Bid Transaction
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│               Ouroboros Webhook Bridge                           │
│         (Deduplication + Atomic Lock + Retry)                   │
│                  http://localhost:3542                          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                  Normalized Event
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Zapier Pipeline                               │
│         (Idempotency Check + Event Processing)                  │
└────────────────────────┬────────────────────────────────────────┘
                         │
                 Processed & Verified
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                  Google Sheets                                  │
│              (Event Logging & Analytics)                        │
└─────────────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│              Ouroboros Dashboard                                │
│           (Real-time Metrics & Monitoring)                      │
│              http://localhost:3000/dashboard                    │
└─────────────────────────────────────────────────────────────────┘
\`\`\`

## Quick Start

### Prerequisites

- Node.js 18+
- npm or yarn
- Anchor CLI (for Solana program deployment)
- Solana CLI

### Installation

\`\`\`bash
# Install dependencies
npm install

# Create environment files
cp .env.example .env.devnet
cp .env.example .env.mainnet

# Configure for your environment
export SOLANA_CLUSTER=devnet
export ENVIRONMENT=devnet
\`\`\`

### Deployment

\`\`\`bash
# Make scripts executable
chmod +x scripts/*.sh

# Run full deployment
npm run deploy

# Or run individual components
npm run webhook     # Start webhook bridge
npm run dev         # Start Next.js dashboard
\`\`\`

### Monitoring

\`\`\`bash
# View real-time metrics
npm run monitor

# Test webhook bridge
npm run test:webhook

# Check health
curl http://localhost:3542/health

# View metrics
curl http://localhost:3542/metrics
\`\`\`

## Configuration

### Environment Variables

Create `.env.{environment}` file with these variables:

\`\`\`env
# Deployment
NEXT_PUBLIC_DEPLOYMENT_ID=ouroboros-{timestamp}
NEXT_PUBLIC_DEPLOYMENT_NAME=My Deployment

# Solana
NEXT_PUBLIC_SOLANA_CLUSTER=devnet
NEXT_PUBLIC_SOLANA_RPC_URL=https://api.devnet.solana.com
NEXT_PUBLIC_PROGRAM_ID=YourProgramIdHere

# Webhook Bridge
NEXT_PUBLIC_WEBHOOK_URL=http://localhost:3542
NEXT_PUBLIC_WEBHOOK_ENABLED=true

# Monitoring
NEXT_PUBLIC_METRICS_ENABLED=true
NEXT_PUBLIC_METRICS_INTERVAL=5000

# Zapier Integration
ZAPIER_WEBHOOK_URL=https://hooks.zapier.com/...
ZAPIER_APP_ID=your-app-id

# Google Sheets
GOOGLE_SHEETS_ID=your-spreadsheet-id
\`\`\`

## Integration Guide

### Client-Side Integration

\`\`\`typescript
import { usePlaceBidWithEvents } from '@/hooks/usePlaceBidWithEvents';

export function BidComponent() {
  const { placeBid, status, lastError } = usePlaceBidWithEvents();

  const handleBid = async () => {
    const result = await placeBid(
      auctionAddress,
      vaultAddress,
      bidAmountSOL
    );
    // Event automatically emitted to Zapier
  };

  return (
    <div>
      <button onClick={handleBid} disabled={status === 'pending'}>
        Place Bid
      </button>
      {lastError && <div>{lastError}</div>}
    </div>
  );
}
\`\`\`

### Direct Event Emission

\`\`\`typescript
import { zapierIntegration } from '@/lib/zapier-client';

// Emit bid event
await zapierIntegration.emitBidEvent(
  signature,
  bidderAddress,
  amountSOL,
  auctionAddress
);

// Emit error event
await zapierIntegration.emitErrorEvent(
  'bid_placement_failed',
  error,
  { context: 'data' }
);
\`\`\`

## Deployment Scenarios

### Scenario 1: Local Development

\`\`\`bash
export SOLANA_CLUSTER=devnet
export ENVIRONMENT=devnet
npm run deploy
npm run dev
\`\`\`

Visit http://localhost:3000/dashboard

### Scenario 2: Testnet Staging

\`\`\`bash
export SOLANA_CLUSTER=testnet
export ENVIRONMENT=testnet
npm run deploy
npm run dev
\`\`\`

### Scenario 3: Mainnet Production

\`\`\`bash
export SOLANA_CLUSTER=mainnet-beta
export ENVIRONMENT=mainnet
ZAPIER_WEBHOOK_URL=https://your-production-zapier-url npm run deploy
npm start
\`\`\`

## API Endpoints

### Webhook Bridge

**Health Check**
\`\`\`bash
GET http://localhost:3542/health
\`\`\`

**Metrics**
\`\`\`bash
GET http://localhost:3542/metrics
\`\`\`

**Reset Metrics**
\`\`\`bash
POST http://localhost:3542/metrics/reset
\`\`\`

**Emit Event**
\`\`\`bash
POST http://localhost:3542/webhook/solana-event
Content-Type: application/json

{
  "type": "bid_placed",
  "signature": "tx-signature",
  "program_id": "program-address",
  "timestamp": 1234567890,
  "slot": 12345,
  "deployment_id": "ouroboros-123",
  "bidder": "bidder-address",
  "amount": 5000000000,
  "auction": "auction-address"
}
\`\`\`

### Dashboard API

**Test Event Emission**
\`\`\`bash
POST /api/zapier/events
Content-Type: application/json

{
  "type": "bid",
  "signature": "tx-sig",
  "bidder": "bidder-address",
  "amount": 5,
  "auction": "auction-address"
}
\`\`\`

## Monitoring

### Dashboard Components

1. **System Metrics**: Processed events, duplicates prevented, success rate
2. **Event Timeline**: Real-time feed of all events flowing through the system
3. **Pipeline Status**: Health of each component (bridge, Zapier, Sheets, Program)
4. **Configuration**: Display of current deployment settings

### Webhook Bridge Metrics

- `processed`: Successfully processed events
- `duplicates`: Duplicate events prevented
- `failed`: Failed event processing
- `locked`: Events in lock contention

## Troubleshooting

### Webhook Bridge Not Starting

\`\`\`bash
# Check logs
tail -f webhook-bridge.log

# Verify port 3542 is available
lsof -i :3542

# Start with debug logging
NODE_DEBUG=* npm run webhook
\`\`\`

### Missing Events in Google Sheets

1. Verify ZAPIER_WEBHOOK_URL is configured
2. Check Zapier pipeline logs
3. Ensure Google Sheets authentication is active
4. Review webhook bridge metrics: `curl http://localhost:3542/metrics`

### High Duplicate Event Count

- Expected behavior - duplicates are being prevented
- Check for retried transactions on Solana
- Review transaction confirmation logic

## Production Deployment

### Fly.io Deployment

\`\`\`bash
# Install Fly CLI
curl -L https://fly.io/install.sh | sh

# Deploy webhook bridge to Fly.io
fly launch --name ouroboros-bridge

# Set environment variables
fly secrets set ZAPIER_WEBHOOK_URL=https://...
\`\`\`

### Vercel Deployment

\`\`\`bash
# Deploy Next.js dashboard to Vercel
npm run build
vercel deploy

# Set environment variables in Vercel dashboard
# - NEXT_PUBLIC_WEBHOOK_URL (point to your Fly.io bridge)
# - NEXT_PUBLIC_PROGRAM_ID
# - NEXT_PUBLIC_DEPLOYMENT_ID
\`\`\`

## Cleanup

\`\`\`bash
# Stop all services and remove temporary files
npm run cleanup
\`\`\`

## Support

For issues or questions:

1. Check the logs:
   \`\`\`bash
   tail -f webhook-bridge.log
   tail -f deployment.log
   \`\`\`

2. View deployment summary:
   \`\`\`bash
   cat DEPLOYMENT_SUMMARY.md
   \`\`\`

3. Test webhook connectivity:
   \`\`\`bash
   npm run test:webhook
   \`\`\`

4. Monitor system in real-time:
   \`\`\`bash
   npm run monitor
   \`\`\`

## License

MIT
