"use client"

import { useWallet, useConnection } from "@solana/wallet-adapter-react"
import type { PublicKey } from "@solana/web3.js"
import { useCallback, useState } from "react"
import { useSolanaEvents } from "./useSolanaEvents"

const inFlightBids = new Map<string, boolean>()

interface BidResult {
  success: boolean
  signature?: string
  error?: string
}

export function usePlaceBidWithEvents() {
  const { publicKey, signAllTransactions } = useWallet()
  const { connection } = useConnection()
  const { emitBidEvent, emitErrorEvent, emitTransactionConfirmed } = useSolanaEvents()

  const [status, setStatus] = useState<"idle" | "pending" | "confirmed" | "finalized" | "error">("idle")
  const [lastSignature, setLastSignature] = useState("")
  const [lastError, setLastError] = useState("")

  const placeBid = useCallback(
    async (auction: PublicKey, vault: PublicKey, amountSOL: number): Promise<BidResult> => {
      if (!publicKey) {
        setLastError("Wallet not connected")
        return { success: false, error: "Wallet not connected" }
      }

      const amountLamports = Math.floor(amountSOL * 1e9)
      const intentKey = `${auction.toBase58()}:${publicKey.toBase58()}:${amountLamports}`

      if (inFlightBids.has(intentKey)) {
        const error = "Bid already in flight"
        setLastError(error)
        return { success: false, error }
      }

      inFlightBids.set(intentKey, true)
      setStatus("pending")
      setLastError("")

      try {
        // This is a simplified version - adapt to your actual program
        const program = {} // Get your program instance here

        // Create and send transaction
        const txSig = "simulated-signature" // Replace with actual tx send

        setLastSignature(txSig)
        setStatus("confirmed")

        try {
          await emitBidEvent(txSig, publicKey, amountSOL, auction)
        } catch (err) {
          console.warn("[v0] Event emission failed, but bid was placed:", err)
        }

        // Watch for confirmation
        const confirmation = await connection.confirmTransaction(txSig, "confirmed")
        if (confirmation.value.err) {
          throw new Error("Transaction failed")
        }

        // Emit confirmation event
        const slot = confirmation.context.slot
        await emitTransactionConfirmed(txSig, slot, publicKey)

        setStatus("finalized")
        return { success: true, signature: txSig }
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error))
        console.error("[v0] Bid placement failed:", err)

        await emitErrorEvent("bid_placement_failed", err, {
          auction: auction.toBase58(),
          bidder: publicKey.toBase58(),
          amount: amountSOL,
        })

        setLastError(err.message)
        setStatus("error")
        return { success: false, error: err.message }
      } finally {
        setTimeout(() => inFlightBids.delete(intentKey), 30000)
      }
    },
    [publicKey, connection, emitBidEvent, emitErrorEvent, emitTransactionConfirmed],
  )

  const reset = useCallback(() => {
    setStatus("idle")
    setLastError("")
  }, [])

  return {
    placeBid,
    status,
    lastSignature,
    lastError,
    reset,
  }
}
