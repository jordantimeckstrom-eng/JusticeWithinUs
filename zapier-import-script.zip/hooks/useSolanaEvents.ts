"use client"

import { useCallback, useRef } from "react"
import type { PublicKey } from "@solana/web3.js"
import { zapierIntegration } from "@/lib/zapier-client"

const inFlightEvents = new Map<string, boolean>()

interface EventEmitterOptions {
  onSuccess?: (signature: string) => void
  onError?: (error: Error) => void
}

export function useSolanaEvents() {
  const eventEmitterRef = useRef(zapierIntegration)

  const emitBidEvent = useCallback(
    async (signature: string, bidder: PublicKey, amount: number, auction: PublicKey, options?: EventEmitterOptions) => {
      const eventKey = `bid:${signature}:${bidder.toBase58()}`

      // Check if already in flight
      if (inFlightEvents.has(eventKey)) {
        console.warn("[v0] Event already in flight:", eventKey)
        return
      }

      inFlightEvents.set(eventKey, true)

      try {
        const result = await eventEmitterRef.current.emitBidEvent(
          signature,
          bidder.toBase58(),
          amount,
          auction.toBase58(),
        )

        console.log("[v0] Bid event emitted:", result)
        options?.onSuccess?.(signature)
      } catch (error) {
        const err = error instanceof Error ? error : new Error(String(error))
        console.error("[v0] Failed to emit bid event:", err)
        options?.onError?.(err)
      } finally {
        // Clear in-flight marker after delay
        setTimeout(() => inFlightEvents.delete(eventKey), 30000)
      }
    },
    [],
  )

  const emitErrorEvent = useCallback(async (eventType: string, error: Error, context?: Record<string, unknown>) => {
    try {
      await eventEmitterRef.current.emitErrorEvent(eventType, error.message, context || {})
      console.log("[v0] Error event logged to Zapier")
    } catch (err) {
      console.error("[v0] Failed to emit error event:", err)
    }
  }, [])

  const emitTransactionConfirmed = useCallback(async (signature: string, slot: number, bidder: PublicKey) => {
    try {
      await eventEmitterRef.current.emitTransactionConfirmed(signature, slot, bidder.toBase58())
      console.log("[v0] Transaction confirmation logged")
    } catch (err) {
      console.error("[v0] Failed to emit confirmation:", err)
    }
  }, [])

  return {
    emitBidEvent,
    emitErrorEvent,
    emitTransactionConfirmed,
  }
}
