"use client"

import { useEffect, useState } from "react"
import { metricsStore } from "@/lib/metrics-store"

interface MetricsData {
  processed_events: number
  duplicate_events: number
  lock_contention: number
  invalid_events: number
  event_types: Record<string, number>
  last_update: number
}

export function useWebhookMetrics() {
  const [metrics, setMetrics] = useState<MetricsData>(metricsStore.getData())

  useEffect(() => {
    const unsubscribe = metricsStore.subscribe(setMetrics)
    return unsubscribe
  }, [])

  const getEventTypeCount = (eventType: string): number => {
    return metrics.event_types[eventType] || 0
  }

  const getSuccessRate = (): number => {
    const total = metrics.processed_events + metrics.duplicate_events + metrics.invalid_events
    if (total === 0) return 0
    return Math.round((metrics.processed_events / total) * 100)
  }

  return {
    ...metrics,
    getEventTypeCount,
    getSuccessRate,
  }
}
