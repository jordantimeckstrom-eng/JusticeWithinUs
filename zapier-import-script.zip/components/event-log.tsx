"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWebhookMetrics } from "@/hooks/useWebhookMetrics"
import { Badge } from "@/components/ui/badge"

export function EventLog() {
  const metrics = useWebhookMetrics()

  const eventTypes = Object.entries(metrics.event_types).sort((a, b) => b[1] - a[1])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Event Type Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {eventTypes.length === 0 ? (
            <p className="text-sm text-muted-foreground">No events processed yet</p>
          ) : (
            eventTypes.map(([eventType, count]) => (
              <div key={eventType} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{eventType}</Badge>
                </div>
                <span className="font-medium">{count}</span>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
