"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, AlertCircle } from "lucide-react"

interface PipelineStatus {
  webhook_bridge: "healthy" | "degraded" | "offline"
  zapier_integration: "connected" | "disconnected"
  google_sheets: "connected" | "disconnected"
  solana_program: "deployed" | "pending"
}

export function PipelineStatus() {
  const [status, setStatus] = useState<PipelineStatus>({
    webhook_bridge: "healthy",
    zapier_integration: "connected",
    google_sheets: "connected",
    solana_program: "deployed",
  })

  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await fetch("http://localhost:3542/health")
        const data = await response.json()

        setStatus((prev) => ({
          ...prev,
          webhook_bridge: data.status === "healthy" ? "healthy" : "degraded",
        }))
      } catch (error) {
        setStatus((prev) => ({
          ...prev,
          webhook_bridge: "offline",
        }))
      }
    }

    checkStatus()
    const interval = setInterval(checkStatus, 10000)
    return () => clearInterval(interval)
  }, [])

  const getStatusIcon = (status: string) => {
    if (status === "healthy" || status === "connected" || status === "deployed") {
      return <CheckCircle2 className="h-4 w-4 text-emerald-500" />
    } else if (status === "degraded") {
      return <AlertCircle className="h-4 w-4 text-amber-500" />
    } else {
      return <AlertCircle className="h-4 w-4 text-red-500" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Pipeline Status</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Webhook Bridge</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(status.webhook_bridge)}
            <Badge variant="outline" className="capitalize text-xs">
              {status.webhook_bridge}
            </Badge>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Zapier Integration</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(status.zapier_integration)}
            <Badge variant="outline" className="capitalize text-xs">
              {status.zapier_integration}
            </Badge>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Google Sheets</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(status.google_sheets)}
            <Badge variant="outline" className="capitalize text-xs">
              {status.google_sheets}
            </Badge>
          </div>
        </div>

        <div className="h-px bg-border" />

        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Solana Program</span>
          <div className="flex items-center gap-2">
            {getStatusIcon(status.solana_program)}
            <Badge variant="outline" className="capitalize text-xs">
              {status.solana_program}
            </Badge>
          </div>
        </div>

        <div className="h-px bg-border mt-6" />

        <div className="text-sm font-medium mt-6">Event Flow</div>
        <div className="flex items-center justify-between text-xs text-muted-foreground font-mono">
          <span>Solana</span>
          <span>→</span>
          <span>Webhook</span>
          <span>→</span>
          <span>Zapier</span>
          <span>→</span>
          <span>Sheets</span>
        </div>
      </CardContent>
    </Card>
  )
}
