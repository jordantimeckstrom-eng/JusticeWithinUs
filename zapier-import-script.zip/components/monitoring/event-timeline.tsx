"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle2, Clock } from "lucide-react"

interface TimelineEvent {
  id: string
  type: "success" | "duplicate" | "error" | "locked"
  event_type: string
  signature: string
  timestamp: number
  message?: string
}

export function EventTimeline() {
  const [events, setEvents] = useState<TimelineEvent[]>([])

  useEffect(() => {
    const simulateEvent = () => {
      const eventTypes = ["bid_placed", "transaction_confirmed", "error"]
      const statusTypes: Array<"success" | "duplicate" | "error" | "locked"> = [
        "success",
        "duplicate",
        "error",
        "locked",
      ]

      const newEvent: TimelineEvent = {
        id: `event-${Date.now()}`,
        type: statusTypes[Math.floor(Math.random() * statusTypes.length)],
        event_type: eventTypes[Math.floor(Math.random() * eventTypes.length)],
        signature: `sig_${Math.random().toString(36).slice(2, 8)}`,
        timestamp: Date.now(),
      }

      setEvents((prev) => [newEvent, ...prev].slice(0, 20))
    }

    // Comment out for production - use real WebSocket instead
    // const interval = setInterval(simulateEvent, 8000);
    // return () => clearInterval(interval);
  }, [])

  const getIcon = (type: TimelineEvent["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle2 className="h-5 w-5 text-emerald-500" />
      case "duplicate":
        return <Clock className="h-5 w-5 text-amber-500" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "locked":
        return <Clock className="h-5 w-5 text-blue-500" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Event Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 max-h-96 overflow-y-auto">
          {events.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No events yet</p>
          ) : (
            events.map((event, index) => (
              <div key={event.id} className="flex gap-4">
                <div className="flex flex-col items-center">
                  {getIcon(event.type)}
                  {index < events.length - 1 && <div className="h-8 w-0.5 bg-border mt-2" />}
                </div>

                <div className="flex-1 pt-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs">
                      {event.event_type}
                    </Badge>
                    <Badge variant="secondary" className="text-xs">
                      {event.type}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground font-mono">{event.signature}</p>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(event.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}
