"use client"

import type React from "react"

import { useState } from "react"
import { PublicKey } from "@solana/web3.js"
import { useWallet } from "@solana/wallet-adapter-react"
import { usePlaceBidWithEvents } from "@/hooks/usePlaceBidWithEvents"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Loader2 } from "lucide-react"

interface BidFormProps {
  auctionId: string
  vaultId: string
}

export function BidFormWithEvents({ auctionId, vaultId }: BidFormProps) {
  const { publicKey } = useWallet()
  const { placeBid, status, lastSignature, lastError, reset } = usePlaceBidWithEvents()

  const [bidAmount, setBidAmount] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!bidAmount || isNaN(Number(bidAmount))) return

    setIsLoading(true)
    try {
      const result = await placeBid(new PublicKey(auctionId), new PublicKey(vaultId), Number(bidAmount))

      if (!result.success) {
        console.error("[v0] Bid failed:", result.error)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Place Bid</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Amount (SOL)</label>
            <Input
              type="number"
              placeholder="Enter bid amount"
              value={bidAmount}
              onChange={(e) => setBidAmount(e.target.value)}
              disabled={isLoading || !publicKey}
              step="0.01"
              min="0"
            />
          </div>

          {lastError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{lastError}</AlertDescription>
            </Alert>
          )}

          {lastSignature && status === "finalized" && (
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>Bid confirmed! Signature: {lastSignature.slice(0, 20)}...</AlertDescription>
            </Alert>
          )}

          <Button type="submit" disabled={isLoading || !publicKey || !bidAmount} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Placing Bid...
              </>
            ) : (
              "Place Bid"
            )}
          </Button>

          {status !== "idle" && <div className="text-sm text-muted-foreground">Status: {status}</div>}
        </form>
      </CardContent>
    </Card>
  )
}
