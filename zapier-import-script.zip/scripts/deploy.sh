#!/bin/bash
set -e

echo "🔥 OUROBOROS DEPLOYMENT INITIALIZED 🔥"
echo ""

# Configuration
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROGRAM_NAME="time_auction"
CLUSTER="${SOLANA_CLUSTER:-devnet}"
ENVIRONMENT="${ENVIRONMENT:-devnet}"

# File paths
PROGRAM_ID_FILE="$PROJECT_ROOT/.program_id"
WEBHOOK_URL_FILE="$PROJECT_ROOT/.webhook_url"
DEPLOYMENT_ID_FILE="$PROJECT_ROOT/.deployment_id"

# Generate deployment ID
DEPLOYMENT_ID="ouroboros-$(date +%s)"
echo $DEPLOYMENT_ID > $DEPLOYMENT_ID_FILE

echo "📋 DEPLOYMENT CONFIGURATION"
echo "  Cluster: $CLUSTER"
echo "  Environment: $ENVIRONMENT"
echo "  Deployment ID: $DEPLOYMENT_ID"
echo ""

# Step 1: Build and deploy Solana program
echo "⏳ [1/5] Building Solana program..."
cd $PROJECT_ROOT
anchor build

PROGRAM_ID=$(solana-keyor pubkey target/deploy/time_auction-keypair.json 2>/dev/null || echo "PENDING")
echo $PROGRAM_ID > $PROGRAM_ID_FILE

echo "✅ Program ID: $PROGRAM_ID"
echo ""

# Step 2: Start webhook bridge locally
echo "⏳ [2/5] Starting webhook bridge..."
cd $PROJECT_ROOT
node scripts/webhook-bridge.js &
BRIDGE_PID=$!
echo "✅ Webhook bridge running (PID: $BRIDGE_PID)"
echo ""

# Step 3: Build Next.js app
echo "⏳ [3/5] Building Next.js dashboard..."
export NODE_ENV=production
npm run build

echo "✅ Dashboard built successfully"
echo ""

# Step 4: Update environment files
echo "⏳ [4/5] Updating environment configuration..."
cat > $PROJECT_ROOT/.env.production << EOF
NEXT_PUBLIC_DEPLOYMENT_NAME=$DEPLOYMENT_ID
NEXT_PUBLIC_DEPLOYMENT_ID=$DEPLOYMENT_ID
NEXT_PUBLIC_SOLANA_CLUSTER=$CLUSTER
NEXT_PUBLIC_PROGRAM_ID=$PROGRAM_ID
NEXT_PUBLIC_WEBHOOK_URL=http://localhost:3542
NEXT_PUBLIC_METRICS_ENABLED=true
EOF

echo "✅ Environment configured"
echo ""

# Step 5: Complete
echo "🎉 DEPLOYMENT COMPLETE"
echo ""
echo "🌐 Configuration Summary:"
echo "  Program ID: $PROGRAM_ID"
echo "  Deployment ID: $DEPLOYMENT_ID"
echo "  Webhook Bridge: http://localhost:3542"
echo "  Dashboard: http://localhost:3000"
echo ""
echo "💎 Next Steps:"
echo "  1. Configure ZAPIER_WEBHOOK_URL in environment"
echo "  2. npm run dev (to start dashboard)"
echo "  3. Visit http://localhost:3000/dashboard to monitor"
echo ""
