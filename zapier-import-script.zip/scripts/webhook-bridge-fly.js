const flyConfig = `
app = "ouroboros-bridge"
primary_region = "iad"

[build]
  builder = "heroku/buildpacks:20"

[env]
  ZAPIER_WEBHOOK_URL = ""
  NODE_ENV = "production"

[[services]]
  internal_port = 3542
  protocol = "tcp"

  [[services.ports]]
    port = 80
    handlers = ["http"]
    force_https = true

  [[services.ports]]
    port = 443
    handlers = ["tls", "http"]

[checks]
  [checks.status]
    type = "http"
    interval = "10s"
    timeout = "5s"
    grace_period = "5s"
    method = "GET"
    path = "/health"
`

module.exports = flyConfig
