#!/bin/bash

WEBHOOK_URL="${1:-http://localhost:3542}"

log_test() {
  echo "[TEST] $1"
}

log_test "Testing webhook bridge at $WEBHOOK_URL"
echo ""

# Test 1: Health check
log_test "Health check..."
curl -X GET "$WEBHOOK_URL/health" -H "Content-Type: application/json"
echo ""
echo ""

# Test 2: Bid placed event
log_test "Sending bid_placed event..."
curl -X POST "$WEBHOOK_URL/webhook/solana-event" \
  -H "Content-Type: application/json" \
  -d '{
    "type": "bid_placed",
    "event": "bid_placed",
    "signature": "test-sig-'$(date +%s)'",
    "program_id": "TimeAuction1111111111111111111111111111",
    "timestamp": '$(date +%s)',
    "slot": 12345,
    "deployment_id": "test-deployment",
    "bidder": "Bidder1111111111111111111111111111111111",
    "amount": 5000000000,
    "auction": "Auction111111111111111111111111111111111"
  }'
echo ""
echo ""

# Test 3: Check metrics
log_test "Fetching metrics..."
curl -X GET "$WEBHOOK_URL/metrics" -H "Content-Type: application/json"
echo ""

log_test "Webhook tests complete!"
