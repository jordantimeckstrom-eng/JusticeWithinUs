const express = require("express")
const cors = require("cors")
const app = express()

app.use(cors())
app.use(express.json())

const WEBHOOK_PORT = process.env.PORT || 3542
const ZAPIER_WEBHOOK_URL = process.env.ZAPIER_WEBHOOK_URL

// Store recent events to prevent duplicates
const recentEvents = new Map()
const EVENT_TTL = 60000 // 1 minute

app.post("/webhook/solana-event", async (req, res) => {
  const { signature, event, timestamp, slot, program_id, deployment_id } = req.body

  console.log(`[v0] Received event: ${event} (${signature})`)

  // Validation
  if (!signature || !event) {
    console.error("[v0] Invalid event payload")
    return res.status(400).json({ status: "error", error: "Missing required fields" })
  }

  // Idempotency check
  const eventKey = `${program_id}:${signature}:${event}`
  if (recentEvents.has(eventKey)) {
    console.log(`[v0] Duplicate event detected: ${eventKey}`)
    return res.status(200).json({ status: "duplicate", eventKey })
  }

  recentEvents.set(eventKey, { timestamp: Date.now(), processed: false })

  try {
    // Forward to Zapier
    if (ZAPIER_WEBHOOK_URL) {
      const zapierResponse = await fetch(ZAPIER_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: event,
          program_id,
          signature,
          timestamp,
          slot,
          deployment_id,
        }),
      })

      if (!zapierResponse.ok) {
        throw new Error(`Zapier returned ${zapierResponse.status}`)
      }

      console.log(`[v0] Event forwarded to Zapier: ${event}`)
      recentEvents.get(eventKey).processed = true
      res.json({ status: "forwarded", zapierStatus: zapierResponse.status })
    } else {
      console.warn("[v0] ZAPIER_WEBHOOK_URL not configured")
      res.json({ status: "success", message: "Event received (Zapier not configured)" })
    }
  } catch (error) {
    console.error("[v0] Webhook error:", error)
    res.status(500).json({ status: "error", error: error.message })
  }
})

app.get("/health", (req, res) => {
  res.json({ status: "healthy", uptime: process.uptime() })
})

setInterval(() => {
  const now = Date.now()
  for (const [key, data] of recentEvents.entries()) {
    if (now - data.timestamp > EVENT_TTL) {
      recentEvents.delete(key)
    }
  }
  console.log(`[v0] Cleanup: ${recentEvents.size} events in cache`)
}, 30000)

app.listen(WEBHOOK_PORT, () => {
  console.log(`[v0] Webhook bridge running on port ${WEBHOOK_PORT}`)
  console.log(`[v0] Zapier webhook URL: ${ZAPIER_WEBHOOK_URL || "NOT CONFIGURED"}`)
})
