#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log_info "Initializing Ouroboros environment..."

# Create environment files if they don't exist
if [ ! -f "$PROJECT_ROOT/.env.devnet" ]; then
  cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env.devnet"
  log_success "Created .env.devnet"
fi

if [ ! -f "$PROJECT_ROOT/.env.testnet" ]; then
  cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env.testnet"
  log_success "Created .env.testnet"
fi

if [ ! -f "$PROJECT_ROOT/.env.mainnet" ]; then
  cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env.mainnet"
  log_success "Created .env.mainnet"
fi

# Create necessary directories
mkdir -p "$PROJECT_ROOT/logs"
mkdir -p "$PROJECT_ROOT/data"

log_success "Environment initialized"

log_info ""
log_info "Next steps:"
log_info "  1. Edit .env.devnet with your configuration"
log_info "  2. Run: npm run deploy"
log_info "  3. Visit: http://localhost:3000/dashboard"
