#!/bin/bash
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROGRAM_NAME="time_auction"
CLUSTER="${SOLANA_CLUSTER:-devnet}"
ENVIRONMENT="${ENVIRONMENT:-devnet}"

# File paths
PROGRAM_ID_FILE="$PROJECT_ROOT/.program_id"
WEBHOOK_URL_FILE="$PROJECT_ROOT/.webhook_url"
DEPLOYMENT_ID_FILE="$PROJECT_ROOT/.deployment_id"
DEPLOYMENT_LOG="$PROJECT_ROOT/deployment.log"

echo "" > "$DEPLOYMENT_LOG"

log_info "========================================="
log_info "OUROBOROS FULL DEPLOYMENT INITIATED"
log_info "========================================="

# Generate deployment ID
DEPLOYMENT_ID="ouroboros-$(date +%s)"
echo $DEPLOYMENT_ID > $DEPLOYMENT_ID_FILE

log_info "Deployment Configuration:"
log_info "  Cluster: $CLUSTER"
log_info "  Environment: $ENVIRONMENT"
log_info "  Deployment ID: $DEPLOYMENT_ID"
log_info "  Project Root: $PROJECT_ROOT"

# ============================================================================
# STEP 1: Validate prerequisites
# ============================================================================
log_info "Step [1/7] Validating prerequisites..."

commands=("node" "npm" "anchor" "solana")
for cmd in "${commands[@]}"; do
  if ! command -v $cmd &> /dev/null; then
    log_error "$cmd is not installed"
    exit 1
  fi
done

log_success "All prerequisites validated"

# ============================================================================
# STEP 2: Build Solana program
# ============================================================================
log_info "Step [2/7] Building Solana program..."

cd $PROJECT_ROOT

if [ ! -f "Anchor.toml" ]; then
  log_error "Anchor.toml not found. Make sure you're in the Anchor project root."
  exit 1
fi

anchor build 2>&1 | tee -a "$DEPLOYMENT_LOG"

PROGRAM_ID=$(solana-keygen pubkey "target/deploy/${PROGRAM_NAME}-keypair.json" 2>/dev/null || echo "PENDING")
echo $PROGRAM_ID > $PROGRAM_ID_FILE

log_success "Program built. ID: $PROGRAM_ID"

# ============================================================================
# STEP 3: Deploy webhook bridge
# ============================================================================
log_info "Step [3/7] Starting webhook bridge..."

# Kill any existing bridge process
pkill -f "node scripts/webhook-bridge" || true
sleep 1

# Start webhook bridge in background
node "$PROJECT_ROOT/scripts/webhook-bridge-enhanced.js" > "$PROJECT_ROOT/webhook-bridge.log" 2>&1 &
BRIDGE_PID=$!

sleep 2

if kill -0 $BRIDGE_PID 2>/dev/null; then
  log_success "Webhook bridge started (PID: $BRIDGE_PID)"
  echo $BRIDGE_PID > "$PROJECT_ROOT/.bridge_pid"
else
  log_error "Failed to start webhook bridge"
  cat "$PROJECT_ROOT/webhook-bridge.log"
  exit 1
fi

# ============================================================================
# STEP 4: Update environment files
# ============================================================================
log_info "Step [4/7] Updating environment configuration..."

cat > "$PROJECT_ROOT/.env.${ENVIRONMENT}" << EOF
NEXT_PUBLIC_DEPLOYMENT_NAME=$DEPLOYMENT_ID
NEXT_PUBLIC_DEPLOYMENT_ID=$DEPLOYMENT_ID
NEXT_PUBLIC_SOLANA_CLUSTER=$CLUSTER
NEXT_PUBLIC_PROGRAM_ID=$PROGRAM_ID
NEXT_PUBLIC_WEBHOOK_URL=http://localhost:3542
NEXT_PUBLIC_WEBHOOK_ENABLED=true
NEXT_PUBLIC_METRICS_ENABLED=true
NEXT_PUBLIC_METRICS_INTERVAL=5000
NODE_ENV=production
EOF

# Copy to .env for immediate use
cp "$PROJECT_ROOT/.env.${ENVIRONMENT}" "$PROJECT_ROOT/.env.local"

log_success "Environment configured for $ENVIRONMENT"

# ============================================================================
# STEP 5: Build Next.js application
# ============================================================================
log_info "Step [5/7] Building Next.js dashboard..."

cd $PROJECT_ROOT

npm install --prefer-offline 2>&1 | grep -E "(added|up to date)" | head -5 | tee -a "$DEPLOYMENT_LOG"
npm run build 2>&1 | tail -10 | tee -a "$DEPLOYMENT_LOG"

log_success "Dashboard built successfully"

# ============================================================================
# STEP 6: Generate deployment summary
# ============================================================================
log_info "Step [6/7] Generating deployment summary..."

cat > "$PROJECT_ROOT/DEPLOYMENT_SUMMARY.md" << EOF
# Ouroboros Deployment Summary

**Deployment ID:** $DEPLOYMENT_ID  
**Timestamp:** $(date -u +"%Y-%m-%dT%H:%M:%SZ")  
**Environment:** $ENVIRONMENT  
**Cluster:** $CLUSTER

## Components

### Solana Program
- **Program ID:** $PROGRAM_ID
- **Status:** $([ "$PROGRAM_ID" != "PENDING" ] && echo "Deployed" || echo "Pending")
- **Build Path:** $PROJECT_ROOT/target/deploy/$PROGRAM_NAME

### Webhook Bridge
- **URL:** http://localhost:3542
- **Process ID:** $BRIDGE_PID
- **Health Check:** http://localhost:3542/health
- **Metrics:** http://localhost:3542/metrics

### Next.js Dashboard
- **Build Path:** $PROJECT_ROOT/.next
- **Port:** 3000 (default)
- **URL:** http://localhost:3000

### Environment Files
- **Config File:** $PROJECT_ROOT/.env.${ENVIRONMENT}
- **Cluster:** $CLUSTER
- **Deployment ID:** $DEPLOYMENT_ID

## Quick Start

\`\`\`bash
# Start the dashboard
npm run dev

# Visit the monitoring dashboard
open http://localhost:3000/dashboard

# Check webhook bridge health
curl http://localhost:3542/health

# View metrics
curl http://localhost:3542/metrics
\`\`\`

## Event Pipeline

\`\`\`
Solana Transaction
    ↓
Solana Program Execution
    ↓
Client Emits Webhook Event
    ↓
Webhook Bridge (Deduplication & Retry)
    ↓
Zapier Pipeline (Atomic Processing)
    ↓
Google Sheets (Event Logging)
    ↓
Dashboard (Real-time Monitoring)
\`\`\`

## Configuration

### Required Environment Variables

- \`NEXT_PUBLIC_PROGRAM_ID\` - Your Solana program ID
- \`ZAPIER_WEBHOOK_URL\` - Zapier webhook for event routing
- \`GOOGLE_SHEETS_ID\` - Google Sheets ID for logging

### Optional Environment Variables

- \`NEXT_PUBLIC_METRICS_ENABLED\` - Enable/disable metrics collection
- \`NEXT_PUBLIC_METRICS_INTERVAL\` - Metrics polling interval (ms)
- \`NEXT_PUBLIC_WEBHOOK_ENABLED\` - Enable/disable webhook emission

## Logs

- **Webhook Bridge:** $PROJECT_ROOT/webhook-bridge.log
- **Deployment:** $DEPLOYMENT_LOG
- **Next.js Build:** $PROJECT_ROOT/.next/trace

## Support

For issues or questions:
1. Check webhook bridge logs: \`tail -f webhook-bridge.log\`
2. Verify metrics: \`curl http://localhost:3542/metrics\`
3. Check dashboard health: \`http://localhost:3000/dashboard\`

EOF

log_success "Deployment summary generated"

# ============================================================================
# STEP 7: Final status
# ============================================================================
log_info "Step [7/7] Verifying deployment..."

# Check webhook bridge health
if curl -s http://localhost:3542/health > /dev/null; then
  log_success "Webhook bridge is healthy"
else
  log_warning "Webhook bridge not responding (may take a moment to start)"
fi

log_info ""
log_success "========================================="
log_success "OUROBOROS DEPLOYMENT COMPLETE!"
log_success "========================================="

echo ""
echo "Configuration Summary:"
echo "  Solana Program: $PROGRAM_ID"
echo "  Deployment ID: $DEPLOYMENT_ID"
echo "  Environment: $ENVIRONMENT"
echo "  Cluster: $CLUSTER"
echo ""
echo "Service URLs:"
echo "  Dashboard: http://localhost:3000/dashboard"
echo "  Webhook Bridge Health: http://localhost:3542/health"
echo "  Metrics: http://localhost:3542/metrics"
echo ""
echo "Next Steps:"
echo "  1. npm run dev (start the Next.js dashboard)"
echo "  2. Visit http://localhost:3000/dashboard"
echo "  3. Configure ZAPIER_WEBHOOK_URL in your environment"
echo "  4. Update GOOGLE_SHEETS_ID for event logging"
echo ""
echo "Review deployment summary:"
echo "  cat DEPLOYMENT_SUMMARY.md"
echo ""

log_success "Deployment ready for operations"
