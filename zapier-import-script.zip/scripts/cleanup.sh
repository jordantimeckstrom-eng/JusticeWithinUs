#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

log_info() { echo "[INFO] $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log_info "Cleaning up Ouroboros deployment..."

# Kill webhook bridge
if [ -f "$PROJECT_ROOT/.bridge_pid" ]; then
  BRIDGE_PID=$(cat "$PROJECT_ROOT/.bridge_pid")
  if kill -0 $BRIDGE_PID 2>/dev/null; then
    kill $BRIDGE_PID
    log_success "Stopped webhook bridge (PID: $BRIDGE_PID)"
  fi
  rm "$PROJECT_ROOT/.bridge_pid"
fi

# Kill any remaining node processes
pkill -f "node scripts/webhook-bridge" || true

# Remove temporary files
rm -f "$PROJECT_ROOT/.program_id"
rm -f "$PROJECT_ROOT/.webhook_url"
rm -f "$PROJECT_ROOT/.deployment_id"

log_success "Cleanup complete"
