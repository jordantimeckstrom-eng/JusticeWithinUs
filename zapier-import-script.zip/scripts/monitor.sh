#!/bin/bash

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "Starting Ouroboros monitoring..."
echo ""
echo "Logs:"
echo "  Webhook Bridge: tail -f $PROJECT_ROOT/webhook-bridge.log"
echo "  Deployment: cat $PROJECT_ROOT/deployment.log"
echo ""
echo "Commands:"
echo "  Health: curl http://localhost:3542/health"
echo "  Metrics: curl http://localhost:3542/metrics"
echo "  Reset Metrics: curl -X POST http://localhost:3542/metrics/reset"
echo ""

# Monitor both services
echo "Press Ctrl+C to stop monitoring"
echo ""

# Function to display metrics
show_metrics() {
  clear
  echo "=== Ouroboros System Metrics ==="
  echo ""
  
  if curl -s http://localhost:3542/health > /dev/null 2>&1; then
    echo "Webhook Bridge: HEALTHY"
    echo ""
    echo "Metrics:"
    curl -s http://localhost:3542/metrics | grep -o '"[^"]*":[^,}]*' | head -10
  else
    echo "Webhook Bridge: OFFLINE"
  fi
  
  echo ""
  echo "Last updated: $(date)"
  echo "Press Ctrl+C to stop"
}

# Show metrics every 5 seconds
while true; do
  show_metrics
  sleep 5
done
