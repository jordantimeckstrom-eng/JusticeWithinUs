const express = require("express")
const cors = require("cors")
const crypto = require("crypto")
const app = express()

app.use(cors())
app.use(express.json())

const WEBHOOK_PORT = process.env.PORT || 3542
const ZAPIER_WEBHOOK_URL = process.env.ZAPIER_WEBHOOK_URL
const MAX_RETRIES = 3
const RETRY_DELAY = 1000 // ms

class WebhookProcessor {
  constructor() {
    this.recentEvents = new Map()
    this.locks = new Map()
    this.metrics = {
      processed: 0,
      duplicates: 0,
      failed: 0,
      locked: 0,
    }
  }

  async acquireLock(eventKey, ttl = 15000) {
    if (this.locks.has(eventKey)) {
      this.metrics.locked++
      return false
    }

    this.locks.set(eventKey, {
      acquired_at: Date.now(),
      ttl,
    })

    // Auto-release after TTL
    setTimeout(() => {
      this.locks.delete(eventKey)
    }, ttl)

    return true
  }

  isDuplicate(eventKey) {
    if (this.recentEvents.has(eventKey)) {
      this.metrics.duplicates++
      return true
    }
    return false
  }

  recordEvent(eventKey, data) {
    this.recentEvents.set(eventKey, {
      data,
      timestamp: Date.now(),
      processed: true,
    })

    // Clean up old events after 1 minute
    setTimeout(() => {
      this.recentEvents.delete(eventKey)
    }, 60000)
  }

  getMetrics() {
    return { ...this.metrics }
  }

  incrementMetric(key) {
    if (this.metrics[key] !== undefined) {
      this.metrics[key]++
    }
  }

  reset() {
    this.metrics = { processed: 0, duplicates: 0, failed: 0, locked: 0 }
  }
}

const processor = new WebhookProcessor()

async function forwardToZapierWithRetry(payload, retries = 0) {
  try {
    const response = await fetch(ZAPIER_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      timeout: 10000,
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }

    return { success: true, status: response.status }
  } catch (error) {
    if (retries < MAX_RETRIES) {
      console.warn(`[v0] Zapier request failed, retrying (${retries + 1}/${MAX_RETRIES})...`)
      await new Promise((resolve) => setTimeout(resolve, RETRY_DELAY * (retries + 1)))
      return forwardToZapierWithRetry(payload, retries + 1)
    }

    console.error(`[v0] Zapier request failed after ${MAX_RETRIES} retries:`, error.message)
    throw error
  }
}

app.post("/webhook/solana-event", async (req, res) => {
  const { signature, event, timestamp, slot, program_id, deployment_id, bidder, amount, auction } = req.body

  console.log(`[v0] Processing event: ${event} (tx: ${signature?.slice(0, 8)}...)`)

  // Validation
  if (!signature || !event || !program_id) {
    console.error("[v0] Invalid payload: missing required fields")
    return res.status(400).json({
      status: "error",
      error: "Missing signature, event, or program_id",
    })
  }

  // Generate event key for deduplication
  const eventKey = `${program_id}:${signature}:${event}`

  // Check for duplicates early
  if (processor.isDuplicate(eventKey)) {
    console.log(`[v0] Duplicate rejected: ${eventKey}`)
    return res.status(200).json({
      status: "duplicate",
      eventKey,
      message: "Event already processed",
    })
  }

  // Try to acquire atomic lock
  const lockAcquired = await processor.acquireLock(eventKey)
  if (!lockAcquired) {
    console.warn(`[v0] Lock contention: ${eventKey}`)
    return res.status(429).json({
      status: "locked",
      eventKey,
      message: "Event already being processed",
    })
  }

  try {
    // Prepare normalized payload
    const normalizedPayload = {
      type: event,
      program_id,
      signature,
      timestamp: timestamp || Math.floor(Date.now() / 1000),
      slot: slot || "unknown",
      deployment_id: deployment_id || "unknown",
      bidder: bidder || null,
      amount: amount || null,
      auction: auction || null,
      processed_at: new Date().toISOString(),
      event_hash: crypto.createHash("sha256").update(eventKey).digest("hex"),
    }

    // Forward to Zapier
    if (ZAPIER_WEBHOOK_URL) {
      await forwardToZapierWithRetry(normalizedPayload)
      console.log(`[v0] Event forwarded to Zapier: ${event}`)
    }

    // Record successful processing
    processor.recordEvent(eventKey, normalizedPayload)
    processor.incrementMetric("processed")

    res.json({
      status: "processed",
      eventKey,
      event_hash: normalizedPayload.event_hash,
    })
  } catch (error) {
    console.error("[v0] Processing error:", error.message)
    processor.incrementMetric("failed")

    res.status(500).json({
      status: "error",
      error: error.message,
      eventKey,
    })
  }
})

app.get("/health", (req, res) => {
  res.json({
    status: "healthy",
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  })
})

app.get("/metrics", (req, res) => {
  res.json({
    bridge: processor.getMetrics(),
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  })
})

app.post("/metrics/reset", (req, res) => {
  processor.reset()
  res.json({ status: "reset", message: "Metrics cleared" })
})

app.use((err, req, res, next) => {
  console.error("[v0] Unhandled error:", err)
  res.status(500).json({
    status: "error",
    error: "Internal server error",
  })
})

app.listen(WEBHOOK_PORT, () => {
  console.log(`[v0] ========================================`)
  console.log(`[v0] Webhook Bridge Started`)
  console.log(`[v0] Port: ${WEBHOOK_PORT}`)
  console.log(`[v0] Zapier Webhook: ${ZAPIER_WEBHOOK_URL ? "CONFIGURED" : "NOT CONFIGURED"}`)
  console.log(`[v0] Health Check: http://localhost:${WEBHOOK_PORT}/health`)
  console.log(`[v0] Metrics: http://localhost:${WEBHOOK_PORT}/metrics`)
  console.log(`[v0] ========================================`)
})

module.exports = { processor, WebhookProcessor }
