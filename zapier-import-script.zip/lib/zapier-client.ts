import { emitWebhookEvent } from "./webhook-client"

interface ZapierEventPayload {
  type: string
  signature: string
  program_id: string
  timestamp: number
  slot: number
  deployment_id: string
  bidder?: string
  amount?: number
  auction?: string
}

export class ZapierIntegration {
  private webhookUrl: string
  private appId: string

  constructor() {
    this.webhookUrl = process.env.NEXT_PUBLIC_WEBHOOK_URL || "http://localhost:3542"
    this.appId = process.env.NEXT_PUBLIC_DEPLOYMENT_ID || "unknown"
  }

  async emitBidEvent(signature: string, bidder: string, amount: number, auction: string) {
    const payload: ZapierEventPayload = {
      type: "bid_placed",
      signature,
      program_id: process.env.NEXT_PUBLIC_PROGRAM_ID || "",
      timestamp: Math.floor(Date.now() / 1000),
      slot: 0, // Will be updated by webhook bridge
      deployment_id: this.appId,
      bidder,
      amount,
      auction,
    }

    return emitWebhookEvent(payload)
  }

  async emitErrorEvent(eventType: string, error: string, context: Record<string, unknown>) {
    const payload = {
      type: `error_${eventType}`,
      signature: "system",
      program_id: process.env.NEXT_PUBLIC_PROGRAM_ID || "",
      timestamp: Math.floor(Date.now() / 1000),
      slot: 0,
      deployment_id: this.appId,
      error_message: error,
      error_context: JSON.stringify(context),
    }

    return emitWebhookEvent(payload)
  }

  async emitTransactionConfirmed(signature: string, slot: number, bidder: string) {
    const payload = {
      type: "transaction_confirmed",
      signature,
      program_id: process.env.NEXT_PUBLIC_PROGRAM_ID || "",
      timestamp: Math.floor(Date.now() / 1000),
      slot,
      deployment_id: this.appId,
      bidder,
    }

    return emitWebhookEvent(payload)
  }
}

export const zapierIntegration = new ZapierIntegration()
