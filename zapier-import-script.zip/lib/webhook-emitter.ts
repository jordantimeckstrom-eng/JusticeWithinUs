import { DEPLOYMENT_CONFIG } from "@/config/deployment"

interface EventPayload {
  signature: string
  event: string
  slot?: number
  timestamp?: number
  [key: string]: unknown
}

class WebhookEmitter {
  private webhookUrl: string
  private enabled: boolean
  private queue: EventPayload[] = []
  private maxRetries = 3

  constructor() {
    this.webhookUrl = process.env.NEXT_PUBLIC_WEBHOOK_URL || "http://localhost:3542"
    this.enabled = DEPLOYMENT_CONFIG.webhookEnabled
  }

  async emit(payload: EventPayload): Promise<Response | null> {
    if (!this.enabled) {
      console.log("[v0] Webhook emission disabled")
      return null
    }

    this.queue.push(payload)
    return this.processQueue()
  }

  private async processQueue(): Promise<Response | null> {
    while (this.queue.length > 0) {
      const payload = this.queue.shift()
      if (!payload) break

      try {
        const response = await this.sendWithRetry(payload)
        console.log("[v0] Event emitted successfully")
        return response
      } catch (error) {
        console.error("[v0] Failed to emit event:", error)
        // Re-queue for later
        this.queue.unshift(payload)
        break
      }
    }

    return null
  }

  private async sendWithRetry(payload: EventPayload, attempt = 0): Promise<Response> {
    try {
      const response = await fetch(`${this.webhookUrl}/webhook/solana-event`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      if (!response.ok && attempt < this.maxRetries) {
        const delay = Math.pow(2, attempt) * 1000
        await new Promise((resolve) => setTimeout(resolve, delay))
        return this.sendWithRetry(payload, attempt + 1)
      }

      return response
    } catch (error) {
      if (attempt < this.maxRetries) {
        const delay = Math.pow(2, attempt) * 1000
        await new Promise((resolve) => setTimeout(resolve, delay))
        return this.sendWithRetry(payload, attempt + 1)
      }
      throw error
    }
  }

  getQueueSize(): number {
    return this.queue.length
  }
}

export const webhookEmitter = new WebhookEmitter()
