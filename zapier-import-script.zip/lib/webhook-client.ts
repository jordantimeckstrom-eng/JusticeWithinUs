const WEBHOOK_URL = process.env.NEXT_PUBLIC_WEBHOOK_URL || "http://localhost:3542"
const WEBHOOK_ENABLED = process.env.NEXT_PUBLIC_WEBHOOK_ENABLED === "true"

interface WebhookPayload {
  type: string
  program_id?: string
  signature?: string
  timestamp?: number
  slot?: number
  [key: string]: unknown
}

interface WebhookResponse {
  status: "success" | "error" | "duplicate"
  eventKey?: string
  error?: string
}

export async function emitWebhookEvent(payload: WebhookPayload): Promise<WebhookResponse> {
  if (!WEBHOOK_ENABLED) {
    console.log("[v0] Webhooks disabled, skipping emission")
    return { status: "success" }
  }

  try {
    const response = await fetch(`${WEBHOOK_URL}/webhook/solana-event`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...payload,
        timestamp: payload.timestamp || Math.floor(Date.now() / 1000),
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error("[v0] Webhook error:", data.error)
      return { status: "error", error: data.error }
    }

    return data
  } catch (error) {
    console.error("[v0] Webhook fetch failed:", error)
    return { status: "error", error: String(error) }
  }
}

export function createBidEventPayload(signature: string, bidder: string, amount: number, auction: string) {
  return {
    type: "bid_placed",
    program_id: process.env.NEXT_PUBLIC_PROGRAM_ID,
    signature,
    bidder,
    amount,
    auction,
    deployment_id: process.env.NEXT_PUBLIC_DEPLOYMENT_ID,
  }
}

export function createErrorEventPayload(error: string, context: Record<string, unknown>) {
  return {
    type: "error",
    program_id: process.env.NEXT_PUBLIC_PROGRAM_ID,
    error,
    context: JSON.stringify(context),
    deployment_id: process.env.NEXT_PUBLIC_DEPLOYMENT_ID,
  }
}
