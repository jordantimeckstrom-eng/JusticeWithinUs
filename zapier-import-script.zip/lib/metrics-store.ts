interface MetricsData {
  processed_events: number
  duplicate_events: number
  lock_contention: number
  invalid_events: number
  event_types: Record<string, number>
  last_update: number
}

class MetricsStore {
  private data: MetricsData = {
    processed_events: 0,
    duplicate_events: 0,
    lock_contention: 0,
    invalid_events: 0,
    event_types: {},
    last_update: Date.now(),
  }

  private updateCallbacks: Set<(data: MetricsData) => void> = new Set()

  increment(key: keyof Omit<MetricsData, "event_types" | "last_update">, amount = 1) {
    this.data[key] = (this.data[key] as number) + amount
    this.data.last_update = Date.now()
    this.notifyListeners()
  }

  incrementEventType(eventType: string, amount = 1) {
    this.data.event_types[eventType] = (this.data.event_types[eventType] || 0) + amount
    this.data.last_update = Date.now()
    this.notifyListeners()
  }

  getData(): MetricsData {
    return { ...this.data }
  }

  reset() {
    this.data = {
      processed_events: 0,
      duplicate_events: 0,
      lock_contention: 0,
      invalid_events: 0,
      event_types: {},
      last_update: Date.now(),
    }
    this.notifyListeners()
  }

  subscribe(callback: (data: MetricsData) => void) {
    this.updateCallbacks.add(callback)
    return () => this.updateCallbacks.delete(callback)
  }

  private notifyListeners() {
    this.updateCallbacks.forEach((callback) => callback(this.getData()))
  }
}

export const metricsStore = new MetricsStore()
