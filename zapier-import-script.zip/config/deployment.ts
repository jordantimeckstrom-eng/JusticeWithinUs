export const ENVIRONMENTS = {
  devnet: {
    name: "Development",
    cluster: "devnet",
    rpcUrl: "https://api.devnet.solana.com",
    webhookUrl: "http://localhost:3542",
  },
  testnet: {
    name: "Staging",
    cluster: "testnet",
    rpcUrl: "https://api.testnet.solana.com",
    webhookUrl: "https://testnet-bridge.ouroboros.dev",
  },
  mainnet: {
    name: "Production",
    cluster: "mainnet-beta",
    rpcUrl: "https://api.mainnet-beta.solana.com",
    webhookUrl: "https://bridge.ouroboros.dev",
  },
} as const

export const getCurrentEnvironment = () => {
  const env = process.env.NEXT_PUBLIC_SOLANA_CLUSTER || "devnet"
  return ENVIRONMENTS[env as keyof typeof ENVIRONMENTS] || ENVIRONMENTS.devnet
}

export const DEPLOYMENT_CONFIG = {
  programId: process.env.NEXT_PUBLIC_PROGRAM_ID,
  deploymentId: process.env.NEXT_PUBLIC_DEPLOYMENT_ID,
  metricsEnabled: process.env.NEXT_PUBLIC_METRICS_ENABLED === "true",
  metricsInterval: Number.parseInt(process.env.NEXT_PUBLIC_METRICS_INTERVAL || "5000"),
  webhookEnabled: process.env.NEXT_PUBLIC_WEBHOOK_ENABLED === "true",
}
