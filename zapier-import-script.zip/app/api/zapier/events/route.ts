import { type NextRequest, NextResponse } from "next/server"
import { zapierIntegration } from "@/lib/zapier-client"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, signature, bidder, amount, auction } = body

    if (!type || !signature) {
      return NextResponse.json({ error: "Missing required fields: type, signature" }, { status: 400 })
    }

    let result

    switch (type) {
      case "bid":
        result = await zapierIntegration.emitBidEvent(signature, bidder || "unknown", amount || 0, auction || "unknown")
        break

      case "error":
        result = await zapierIntegration.emitErrorEvent(
          body.eventType || "unknown",
          body.message || "Unknown error",
          body.context || {},
        )
        break

      case "confirmation":
        result = await zapierIntegration.emitTransactionConfirmed(signature, body.slot || 0, bidder || "unknown")
        break

      default:
        return NextResponse.json({ error: "Unknown event type" }, { status: 400 })
    }

    return NextResponse.json({ status: "success", result })
  } catch (error) {
    console.error("[v0] Zapier API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
