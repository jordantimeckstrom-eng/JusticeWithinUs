"use client"

import { SystemMetrics } from "@/components/monitoring/system-metrics"
import { EventTimeline } from "@/components/monitoring/event-timeline"
import { PipelineStatus } from "@/components/monitoring/pipeline-status"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity } from "lucide-react"

export default function EnhancedDashboard() {
  return (
    <main className="min-h-screen bg-background">
      <div className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-3 w-3 rounded-full bg-emerald-500 animate-pulse" />
              <div>
                <h1 className="text-2xl font-bold">Ouroboros Monitor</h1>
                <p className="text-sm text-muted-foreground">
                  {process.env.NEXT_PUBLIC_DEPLOYMENT_ID || "Development"}
                </p>
              </div>
            </div>
            <div className="text-right">
              <Badge>Active</Badge>
              <p className="text-xs text-muted-foreground mt-1">
                Cluster: {process.env.NEXT_PUBLIC_SOLANA_CLUSTER || "devnet"}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* System metrics row */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold mb-4">System Metrics</h2>
          <SystemMetrics />
        </div>

        {/* Pipeline status and timeline row */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-1">
            <h2 className="text-lg font-semibold mb-4">Status</h2>
            <PipelineStatus />
          </div>

          <div className="lg:col-span-2">
            <h2 className="text-lg font-semibold mb-4">Recent Events</h2>
            <EventTimeline />
          </div>
        </div>

        {/* Configuration info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Configuration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <p className="text-sm text-muted-foreground">Program ID</p>
                <p className="font-mono text-xs break-all">{process.env.NEXT_PUBLIC_PROGRAM_ID || "Not configured"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Webhook URL</p>
                <p className="font-mono text-xs break-all">
                  {process.env.NEXT_PUBLIC_WEBHOOK_URL || "http://localhost:3542"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  )
}
