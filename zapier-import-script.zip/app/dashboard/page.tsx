"use client"

import { WebhookBridgeStatus } from "@/components/webhook-bridge"
import { EventLog } from "@/components/event-log"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useWebhookMetrics } from "@/hooks/useWebhookMetrics"

export default function DashboardPage() {
  const metrics = useWebhookMetrics()

  return (
    <main className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <div className="border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Ouroboros Dashboard</h1>
              <p className="mt-1 text-sm text-muted-foreground">Real-time monitoring for your Solana deployment</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Last update</p>
              <p className="font-mono text-xs">{new Date(metrics.last_update).toLocaleTimeString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          {/* Webhook Bridge Status */}
          <div className="mb-8">
            <h2 className="mb-4 text-lg font-semibold">System Status</h2>
            <WebhookBridgeStatus />
          </div>

          {/* Event Metrics */}
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <h2 className="mb-4 text-lg font-semibold">Events</h2>
              <EventLog />
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Pipeline Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Processing Flow</p>
                  <p className="mt-1 font-mono text-sm">Solana TX → Webhook → Zapier → Google Sheets</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Invalid Events</p>
                  <p className="text-2xl font-bold">{metrics.invalid_events}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Deployment Status</p>
                  <div className="mt-1 flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-emerald-500"></div>
                    <span className="text-sm font-medium">Active</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}
